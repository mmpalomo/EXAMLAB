// App.js

import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const [page, setPage] = useState('profile');

  const navigateToNextPage = () => {
    switch (page) {
      case 'profile':
        setPage('resume');
        break;
      case 'resume':
        setPage('about');
        break;
      case 'about':
        setPage('contact');
        break;
      case 'contact':
        setPage('profile');
        break;
      default:
        break;
    }
  };

  const renderPage = () => {
    switch (page) {
      case 'profile':
        return <ProfilePage />;
      case 'resume':
        return <ResumePage />;
      case 'about':
        return <AboutPage />;
        case'contact':
        return <ContactPage/>
      default:
        return null;
    }
  };

  return (
    <TouchableOpacity onPress={navigateToNextPage} style={styles.container}>
      {renderPage()}
    </TouchableOpacity>
  );
};

const ProfilePage = () => (
  <View style={styles.pageContainer}>
    <Image
      source={require('./assets/profile.jpg')} // Replace with your actual profile picture path
      style={styles.profilePicture}
    />
    <Text style={styles.name}>Rey Emmanuel N. Palomo</Text>
    <Text style={styles.course}>Bachelor of Science Information Technology</Text>
  </View>
);

const ResumePage = () => (
  <View style={styles.pageContainer}>
    <Text style={styles.course}>EDUCATIONAL ATTAINMENT:</Text>
    <Text>Elementary: Bonifacio Memorial Elementary School</Text>
    <Text>Elementary Year:(2009-2015)</Text>
    <Text>HighSchool: St.Bernadette College of Valenzuela</Text>
    <Text>HighSchool Year:(2015-2021)</Text>
    <Text>College: Global Reciprocal Colleges</Text>
    <Text>College Year:(2021-)</Text>
  </View>
);

const AboutPage = () => (
  <View style={styles.pageContainer}>
  <Text style={styles.course} >ABOUT ME:</Text>

    <Text> I am a recent graduate with a degree in Information Technology, passionate about leveraging technology to solve real-world problems. During my academic journey, I gained a strong foundation in programming, database management, and systems analysis. Additionally, I am eager to contribute my skills to innovative projects that push the boundaries of what technology can achieve.</Text>
  </View>
);

const ContactPage= () =>(
  <View style={styles.pageContainer}>
  <Text style={styles.course}>CONTACT ME:</Text>
  <Text> Mobile: 09388432659 </Text>

  <TouchableOpacity onPress={() => Linking.openURL('https://www.facebook.com/mmpalomo5/')}>
  <Text> Facebook: https://www.facebook.com/mmpalomo5/</Text>
  </TouchableOpacity>
  </View>

)

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pageContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profilePicture: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  name: {
    marginTop: 10,
    fontSize: 28,
  },
  course:{
    marginTop: 10,
    fontSize: 25,
    textAlign: 'center',
  },
});

export default App;